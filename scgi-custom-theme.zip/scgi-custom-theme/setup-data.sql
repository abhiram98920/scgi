-- SQL to Create Custom Enquiries Table
CREATE TABLE IF NOT EXISTS `wp_enquiries` (
  `id` mediumint(9) NOT NULL AUTO_INCREMENT,
  `type` varchar(20) NOT NULL,
  `name` varchar(100) DEFAULT '',
  `email` varchar(100) DEFAULT '',
  `phone` varchar(20) DEFAULT '',
  `alt_phone` varchar(20) DEFAULT '',
  `state` varchar(50) DEFAULT '',
  `city` varchar(50) DEFAULT '',
  `course_category` varchar(100) DEFAULT '',
  `course_name` varchar(100) DEFAULT '',
  `message` text,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- DEMO DATA FOR SLIDERS (Example)
-- Note: Attachment IDs and Meta keys must match the hand-coded CPT structure in functions.php
INSERT INTO `wp_posts` (`post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_name`, `post_type`, `menu_order`) VALUES
(1, NOW(), NOW(), '', 'Discover Your Potential at SCGI', '', 'publish', 'closed', 'closed', 'slider-1', 'scgi_slider', 0),
(1, NOW(), NOW(), '', 'Excellence in Healthcare Education', '', 'publish', 'closed', 'closed', 'slider-2', 'scgi_slider', 1);

-- DEMO DATA FOR COURSES (Example)
INSERT INTO `wp_posts` (`post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_name`, `post_type`, `menu_order`) VALUES
(1, NOW(), NOW(), 'Comprehensive nursing training.', 'B.Sc Nursing', '', 'publish', 'closed', 'closed', 'bsc-nursing', 'scgi_course', 0),
(1, NOW(), NOW(), 'Advanced clinical skills.', 'M.Sc Nursing', '', 'publish', 'closed', 'closed', 'msc-nursing', 'scgi_course', 1);

-- Note: In a real migration, you would also need to insert into wp_postmeta for subtitles, buttons, etc.
